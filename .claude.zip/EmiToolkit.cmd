@echo off
rem ====================================================================
rem  Emi Toolkit - lanzador
rem  Usa EmiToolkit.exe (launcher compilado con logging y auto-elevacion)
rem  si existe; de lo contrario cae al metodo legacy de PowerShell.
rem  Logs: Data\launcher.log y Data\runtime-error.log
rem ====================================================================
setlocal
set "HERE=%~dp0"

if exist "%HERE%EmiToolkit.exe" (
    start "" "%HERE%EmiToolkit.exe"
) else (
    rem Fallback legacy: sin logging ni captura de errores runtime
    start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%HERE%EmiToolkit.ps1"
)

endlocal
